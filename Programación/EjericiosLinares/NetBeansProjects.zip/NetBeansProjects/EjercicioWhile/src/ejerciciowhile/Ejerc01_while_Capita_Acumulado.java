package ejerciciowhile;

import java.util.Scanner;

public class Ejerc01_while_Capita_Acumulado {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int c;
        int i;
        int n;
        System.out.println("Introduce el capital");
        c = teclado.nextInt();
        System.out.println("Introduce el tipo de interés");
        i = teclado.nextInt();
        System.out.println("Introduce el numero de años");
        n = teclado.nextInt();
        
    }
}
