package ejerciciowhile;

public class EjercicioWhile {

   
    public static void main(String[] args) {
        int aleatorio=1;
        int contador = 1;
        while(contador<=5 && !(aleatorio%7==0)){
            aleatorio= (int) Math.floor(Math.random()*(500))+1;
            System.out.println("El numero aleatorio vale: " + aleatorio );
           contador = contador + 1;
        }
        /*if(aleatorio%7==0){
            System.out.println(aleatorio + "es el valor del numero aleatorio");
        }else{
            System.out.println("");
        }*/
    }
}
