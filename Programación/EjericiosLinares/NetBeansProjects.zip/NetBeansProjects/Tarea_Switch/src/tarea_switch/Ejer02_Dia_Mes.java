/*Leer el nº de un día del mes, decir qué día de la semana es, suponiendo que el uno es lunes.
Utiliza la clase JOptionPane para pedir la información por pantalla*/
package tarea_switch;

import javax.swing.JOptionPane;

public class Ejer02_Dia_Mes {
    public static void main(String[] args) {
        String cadena;
        byte dia;
        cadena = JOptionPane.showInputDialog("introduce un dia de la semana, siendo 1 lunes, 2 martes.... hasta el 31");
        dia = Byte.parseByte(cadena);
        
        switch (dia) {
            case 1, 8, 15, 22, 29:
                cadena = "lunes";
                break;
            case 2, 9, 16, 23, 30:
                cadena = "martes";
                break;
            case 3, 10, 17, 24, 31:
                cadena = "miercoles";
                break;
            case 4, 11, 18, 25:
                cadena = "jueves";
                break;
            case 5, 12, 19, 26:
                cadena = "viernes";
                break;
            case 6, 13, 20, 27:
                cadena = "sabado";
                break;
            case 7, 14, 21, 28:
                cadena = "domingo";
                break;
            default:
                System.out.println("Debes introducirun numero dentro del 1 al 31");
            
        }
        if (dia<=31) {
            System.out.println("El dia de la semana es: " + cadena);
        }
    }
    
}
