/*Programa que nos permita elegir entre tres opciones posibles según la que pulsemos. Si 
pulsamos 
Opción 1: calcular el cuadrado del número leído. 
Opción 2: calcular el doble del número. 
Opción3: calcular la raíz cuadrada del número.
Utiliza la clase Scanner para pedir la información por pantalla*/

package tarea_switch;

import java.util.Scanner;

public class Ejer03_Opciones {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double num;
        byte opcion;
        
        System.out.println("Elige una opción");
        System.out.println("Opción 1: calcular el cuadrado del número leído");
        System.out.println("Opción 2: calcular el doble del número");
        System.out.println("Opción 3: calcular la raíz cuadrada del número");
        
        opcion = teclado.nextByte();
        
        System.out.println("Introduce un número");
        num = teclado.nextDouble();
        
        switch (opcion) {
            case 1:
                num*=num;
                break;
            case 2:
                num*=2;
                break;
            case 3:
                num = Math.sqrt(num);
                break;
            default:
                System.out.println("Tienes que introducir una de las opciones disponibles");    
                
        }
        if(num > 0 && num <= 3) {
            System.out.println("El resultado es: " + num);
        }
    }
    
}
