/*Dado un valor introducido por teclado, escribir el nombre del día de la semana, de forma 
que represente su posición dentro de la semana. Utiliza la clase JOptionPane para pedir la 
información por pantalla*/
package tarea_switch;

import javax.swing.JOptionPane;

public class Ejer01_Dia_Semana {

    public static void main(String[] args) {
        
        String cadena;
        byte dia;
        
        cadena = JOptionPane.showInputDialog("Introduce el dia de la semana, siendo 1 lunes, 2 martes... hasta 7 domingo");
        dia = Byte.parseByte(cadena);

        switch (dia) {
            case 1:
                cadena = "lunes";
                break;
            case 2:
                cadena = "martes";
                break;
            case 3:
                cadena = "miercoles";
                break;
            case 4:
                cadena = "jueves";
                break;
            case 5:
                cadena = "viernes";
                break;
            case 6:
                cadena = "sabado";
                break;
            case 7:
                cadena = "domingo";
                break;
            default:
                System.out.println("Debes introducir un número del 1 al 7");
        }
        if (dia <= 7) {
            System.out.println("El día de la semana es: " + cadena);
        }

    }

}
