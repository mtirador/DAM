package generacionaleatorios;

import java.util.Random;

public class GeneracionAleatorioRandom {
    public static void main(String[] args) {
        int n=3;
        int m=7;
        Random r;
        r= new Random();
        
        int x= r.nextInt(n);
        System.out.println("x1 vale: " + x);
    }
}
