package generacionaleatorios;


public class GeneracionAleatorios {

    public static void main(String[] args) {
        int n=3;
        int m=7;
       int x = (int) Math.floor (Math.random()*(m-n+1))+n;
       /* tambien se puede hacer de esta forma 
        int x = (int) (Math.random()* n); 
        es porque el int esta truncando el numero*/
        System.out.println("x1 vale: " + x);
    }
}
