/*
Programa que declara una variable que almacenará el precio de una vivienda, por ejemplo 
224000.70, después nos visualiza dicho precio en Euros y en pesetas.
El precio de la vivienda en euros es: 224.000,70
El precio de la vivienda en pesetas es: 37.270.580
 */
package ejercicio13;

/**
 *
 * @author daw107
 */
public class Ejercicio13_03 {
    public static void main(String[] args) {
        float precio;
        precio=224000.70F;
        System.out.printf("El precio de la vivienda en euros es: %,.2f\n ", precio);
        System.out.printf("El precio de la vivienda en pesetas es: %,.2f\n ", precio*166.386);
    }
    
}
