package ejercicio13;

import static java.lang.Math.pow;
import java.util.Scanner;

public class Ejercicio13_08 {
    public static void main(String[] args) {
        float radio;
        double area, longitud;
        //Iniciamos
        Scanner teclado = new Scanner(System.in);
        System.out.println("Teclee el radio");
        radio = teclado.nextFloat();
        area = Math.PI * (pow(radio,2));
        longitud= 2 * Math.PI * radio;
        System.out.printf("Area = %,.2f\n", area);
        System.out.printf("Longitud = %,.2f\n", longitud);
    }
   
}
