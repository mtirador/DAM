/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
 /*¿Qué valor tendrán las variables X e Y después de ejecutar las siguientes instrucciones?
X=100
X++
Y=20
Y- -
X+=Y*/
package ejercicio13;

/**
 *
 * @author daw107
 */
public class Ejercicio13_02 {

        public static void main(String[] args) {
            boolean w, x = true, y = true, z = false;
            w = x && y || x && z || y && z;
            System.out.println("El resultado es: "+w);
           // System.out.println(“El resultado es:”+w);
        }
}
