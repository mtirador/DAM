package ejercicio13;

import java.util.Scanner;

public class Ejercicio13_06 {
    public static void main(String[] args) {
        //Introduccion de datos por teclado
        //Creamos objeto del teclado
        Scanner teclado=new Scanner(System.in);
        Float radio, altura;
        Double area_lat,volumen;
        System.out.println("Introduce el radio");
        radio = teclado.nextFloat();
        System.out.println("Introduce la altura ");
        altura = teclado.nextFloat();
        //calculo del area lateral
        area_lat = 2* Math.PI * radio * altura;
        System.out.printf("El área lateral del cilindro es:%,.2f\n", area_lat);
        volumen = Math.PI * Math.pow(radio, 2) * altura;
        System.out.printf("El volumen del cilindro es %,.2f\n", volumen);
    }
}
