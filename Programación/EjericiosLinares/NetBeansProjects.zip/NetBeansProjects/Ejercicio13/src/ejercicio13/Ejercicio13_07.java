package ejercicio13;

public class Ejercicio13_07 {
    public static void main(String[] args) {
        int a = 23, b = 56;
        /* Primera hora guardando los valores iniciales*/
        int af,bf;
        bf = a;
        af = b;
        System.out.println("Los valores iniciales de la a y b son " + a + " y " + b);
        System.out.println("Sus valores intercambiados son " + af + " y " +bf+"\n");
        
        /* Segunda forma sin guardar los valores iniciales */
        int temp;
        System.out.println("Los valores iniciales de la a y b son " + a + " y " + b);
        temp = a;
        a=b;
        b=temp;
        System.out.println("Sus valores intercambiados son " + a + " y " + b);
    }
    
}
