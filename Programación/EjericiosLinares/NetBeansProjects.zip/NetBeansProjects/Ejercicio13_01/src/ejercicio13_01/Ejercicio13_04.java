/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio13_01;

/**
 *
 * @author daw107
 */
import javax.swing.JOptionPane;
import java.util.Scanner;
public class Ejercicio13_04 {
    public static void main(String[] args) {
        float altura;
        float base;
        Scanner teclado =new Scanner(System.in);
        altura=teclado.nextFloat();
        System.out.println("Dame la altura");
        base=teclado.nextFloat();
        System.out.println("Dame la base");
        System.out.println("El area del triangulo es "+(base*altura/2));
    }
}
