/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
 /*¿Qué valor tendrán las variables X e Y después de ejecutar las siguientes instrucciones?
X=100
X++
Y=20
Y- -
X+=Y*/
package ejercicio13_01;

/**
 *
 * @author daw107
 */
public class Ejercicio13_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int X;
        int Y;
        X = 100;
        X++;
        System.out.println("X vale: " + X);
        Y = 20;
        Y--;
        System.out.println("Y vale: " + Y);
        X+= Y;
        System.out.println("X vale: " + X);
    }

}
