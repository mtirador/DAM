/*
 * Programa que dibuja un cuadrado de asteriscos
 */
package depuracion_codigo;

import java.util.Scanner;

/**
 *
 * @author cic
 */
public class Bucle_anidado2 {
     public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numAsteriscosLado;
        
        System.out.print("Introduce el número de astericos por lado: ");
        numAsteriscosLado=entrada.nextInt();
 
        //Dibujamos la parte de arriba del cuadrado
        for(int cont=0;numAsteriscosLado>cont;cont++){
            System.out.print("*");
        }
        System.out.print("\n");
 
        //Usamos un bucle anidado para dibujar los asteriscos del medio
        //Calcula las filas intermedias poniendo un * al inicio y final de llas.
        for(int cont=1;(numAsteriscosLado-2)>=cont;cont++){
            System.out.print("*");//Este es el que se va a poner a la izquierda, y despues de colocarlo pasa al siguiente for
            //Este bucle dibuja los espacio entre el primer y ultimo asterisco
            //de cada una de las filas.
            for (int i=0;(numAsteriscosLado-2)>i;i++){//este lo calcula y nos pone los espacios en blanco
                System.out.print(" ");
            }
            System.out.print("*\n");//aqui va a imprimir el ultimo * de la fila antes de saltar de la linea
        }
 
        //Dibujamos la parte de abajo del cuadrado
        for(int cont=0;numAsteriscosLado>cont;cont++){
            System.out.print("*");
        }
        System.out.print("\n");
    }
       
}
