/*
 * Calcular el factorial de n números introducidos por teclado. 
 * La introducción finaliza al introducir el 0.
 */
package depuracion_codigo;

import java.util.Scanner;

/**
 *
 * @author cic
 */
public class Bucle_anidado1 {
   public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num, fact;
        
        //Intro datos
        System.out.print("Introduce el número: ");
        num=entrada.nextInt();
        
        //Calculo
        while (num !=0) {            
            fact=1;
            for (int i = num; i > 0; i--) {                
                fact*=i;
            }
            System.out.println("El factorial del número "+ num+" es: " +fact);
            
            //Vuelvo a pedir el número
            System.out.print("Introduce el número: ");
            num=entrada.nextInt();       
            
        }
        System.out.println("*************FIN************");
    } 
}
