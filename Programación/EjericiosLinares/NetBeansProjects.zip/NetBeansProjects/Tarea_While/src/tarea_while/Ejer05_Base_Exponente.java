/*Programa que pide una base B y un exponente E para calcular y visualizar el valor de B 
elevado a E sin utilizar ninguna función matemática*/
package tarea_while;

import java.util.Scanner;

public class Ejer05_Base_Exponente {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        double base;
        int exponente;

        System.out.println("Introduce la base");
        base = teclado.nextDouble();

        System.out.println("Introduce el exponente");
        exponente = teclado.nextInt();

        int i = exponente;
        double resultado = 1;

        while (i > 0) {
            resultado *= base;
            i--;
        }
        System.out.println(base + " elevado a " + exponente + "como resultado da " + resultado);

    }

}
