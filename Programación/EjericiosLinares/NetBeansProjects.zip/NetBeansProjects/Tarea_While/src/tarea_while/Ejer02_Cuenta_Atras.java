/*Programa que presente por pantalla una cuenta atrás empezando por 100 y finalizando en 
0, al final escribirá el literal: ¡DESPEGUE!*/
package tarea_while;

import java.util.Scanner;

public class Ejer02_Cuenta_Atras {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int contador;
        
        System.out.println("Ingresa el valor por el que empezará el contador y no siendo mayor de 100");
        contador = teclado.nextInt();
        
        while (contador >=0) {
            System.out.println(contador);
            contador--;
        }
        System.out.println("¡DESPEGUE!");
    }
    
}
