/*Se coloca un capital C a un interés I, durante N años, si el capital se va acumulando, qué 
capital tendré a los N años. Leer C, I, N por teclado*/
package tarea_while;

import java.util.Scanner;

public class Ejer01_c_i_n {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double c;
        double i;
        int n;
        int años = 0;
        
        System.out.println("Introduce el capital inicial");
        c = teclado.nextDouble();
        
        System.out.println("Introduce el tipo de interes");
        i = teclado.nextDouble();
        
        System.out.println("Introduce el número de años");
        n = teclado.nextInt();
         
        while (años < n) {
            c = c * (1 + i/100);
            años++;
        }
            System.out.printf("Despues de %d años, el capital será: %.2f\n", n, c);
        
    }
    
}
