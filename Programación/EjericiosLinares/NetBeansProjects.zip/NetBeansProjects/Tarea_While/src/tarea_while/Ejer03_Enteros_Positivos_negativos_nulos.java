/*Realizar un programa que nos pide 10 números enteros por teclado y nos visualiza cuántos 
de ellos son negativos, cuántos positivos y cuántos nulos*/
package tarea_while;

import java.util.Scanner;

public class Ejer03_Enteros_Positivos_negativos_nulos {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int positivo=0;
        int negativo=0;
        int nulo=0;
        int num;
        int i=1; //variable contador(saber los numeros que ingreso
        
        while (i <= 10) {
            System.out.println("Introduce un número" + (i));
            num = teclado.nextInt();
            if(num>0) {
                positivo++;
            } else if (num<0) {
                negativo++;
            } else {
                nulo++;
            }
           i++; 
        }
        System.out.println("La cantidad de numeros positivos es: " + positivo);
        System.out.println("La cantidad de numeros negativos es: " + negativo);
        System.out.println("La cantidad de numeros nulos es: " + nulo);
    }
    
}
