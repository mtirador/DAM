/*Programa que pide una serie de caracteres por teclado, la serie finaliza al teclear el carácter 
punto ‘.’. Al final nos dirá cuántos caracteres hemos tecleado.*/

package tarea_while;

import java.util.Scanner;

public class Ejer06_Caracter_punto {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        char caracter = '.';
        int suma = 0;
        
        while (caracter != '.') {
            System.out.println("Introduce caracteres");
            caracter = teclado.next().charAt(0);
            suma ++;
        }
        System.out.println("Se ha introducido " + suma + " de valor");
    }
    
}
