/*Programa que calcule el factorial de un número que nos pide por teclado. NOTA: por 
ejemplo, el factorial de 4 es 4*3*2*1=24*/
package tarea_while;

import java.util.Scanner;

public class Ejer04_Factorial {
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        System.out.println("Introduce un número y calculará su factorial");
        int num = teclado.nextInt();
        
        int i = num;
        int factorial = 1; //para que no multiplique por 0
              
        while (i>1) {
            factorial*=i;
            i--; 
        } 
            System.out.println("El factoria del  número dado es: " + num + " " + factorial);
    }
    
}
