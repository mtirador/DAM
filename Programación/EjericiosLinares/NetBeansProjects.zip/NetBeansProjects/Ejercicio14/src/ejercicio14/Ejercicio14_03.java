/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

/**
 *
 * @author isabt
 */
public class Ejercicio14_03 {
    public static void main(String[] args) {
        double num1;
        byte num2;
        int num3;
        num1=12.3;
        num2=(byte) num1;//convertimos la variable num1 en byte para que no de error
        num3=num2;
        System.out.println("num1: "+num1+"\n"+"num2: "+num2+"\n" + "num3: "+num3+"\n");
    }
    
}
