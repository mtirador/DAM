/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

import javax.swing.JOptionPane;

public class Ejercicio14_04 {
    public static void main(String[] args) {
        double a;
        double b;
        double c;
        a=Double.parseDouble(JOptionPane.showInputDialog("Introduce el primer número con decimales"));
        b=Double.parseDouble(JOptionPane.showInputDialog("Introduce el segundo número con decimales"));
        c=Double.parseDouble(JOptionPane.showInputDialog("Introduce el tercer número con decimales"));
        System.out.printf("La media de estos números %,.2f, %,.2f, %,.2f es: %,.2f\n",a,b,c,((a+b+c)/3));
    }
    
}
