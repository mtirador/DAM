package ejercicio14;

import java.util.Scanner;

public class Ejercicio14 {
    
    public enum meses{enero,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre}
    
    public static void main(String[] args) {
        
        byte edad;
        float altura;
        char inicialNom;
        meses mesNac;
        float salario;
        
        Scanner teclado=new Scanner(System.in);
        
        //Pido los datos y lo lee
        System.out.print("Introduce la edad");
        edad=teclado.nextByte();
        System.out.print("\nIntroduce la altura");
        altura=teclado.nextFloat();
        System.out.print("\nIntroduce la inicial del nombre");
        inicialNom=teclado.next().charAt(0);
        System.out.print("\nIntroduce el mes de nacimiento");
        mesNac=meses.valueOf(teclado.next().toLowerCase());
        System.out.print("\nIntroduce el salario");
        salario=teclado.nextFloat();
        
        //Sacamos todos los datos
        System.out.println("----Mis datos son:----");
        System.out.println("\tEdad: " + edad);
        System.out.printf("\tLa altura es: %,.2f\n",altura);
        System.out.println("\tLa inicial del nombre es: "+inicialNom);
        System.out.println("\tEl mes de nacimiento es: "+mesNac);
        System.out.printf("\tEl salario es: %,.2f\n",salario);
    }
    
}
