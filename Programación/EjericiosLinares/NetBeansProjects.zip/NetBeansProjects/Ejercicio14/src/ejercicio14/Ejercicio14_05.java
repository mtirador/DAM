/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio14;

/**
 *
 * @author isabt
 */
public class Ejercicio14_05 {
    public static void main(String[] args) {
        double vivienda=224000d;
        System.out.printf("El valor de la vivienda en euros es %,.2f€ y en dólares es %,.2f$\n", vivienda,(vivienda/0.86));
    }
    
}
