package tarea_if;

import java.util.Scanner;

public class Ejer07_1_10_Par_Impar_Ternario {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num;
        String respuesta;
        
        System.out.println("Introduce un número del 1 al 10");
        num = teclado.nextInt();
        
        respuesta = (num <= 1 && num >= 10)? "El número esta entre el 1 y el 10" : (num % 2==0)? "El número es par ":"El número es impar";
        System.out.println(respuesta);
    }
}
