package tarea_if;

import java.util.Scanner;

public class Ejer06_Par_Impar_Ternario {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int num;
        String respuesta;
        
        System.out.println("Introduce un número");
        num = teclado.nextInt();
        respuesta = num%2==0 ? "El resultado es par" : "El resultado es impar";
        System.out.println(respuesta);
    }
}
