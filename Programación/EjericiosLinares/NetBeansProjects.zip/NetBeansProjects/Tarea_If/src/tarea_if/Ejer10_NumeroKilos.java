/*Programa que nos pide el total de Kg. de naranjas compradas
y nos muestre el total a pagar teniendo en cuenta que si compramos 10 Kg. 
o más el precio unidad es de 1.2€/kg. 
y en caso contrario el precio es de 1.5 €/Kg*/
package tarea_if;

import java.util.Scanner;

public class Ejer10_NumeroKilos {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        double kg;
        double precio;
        
        System.out.println("Introduce el número de kilos que quieres comprar");
        kg = teclado.nextDouble();
        
        if (kg > 10) {
            precio = kg * 1.2;
        } else {
            precio = kg * 1.5;
        }
        System.out.println("El precio final es: " + precio + "€");
    }

}
