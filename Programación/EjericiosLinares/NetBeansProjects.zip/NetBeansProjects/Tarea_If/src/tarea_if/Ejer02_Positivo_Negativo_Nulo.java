/*Escribir un programa que nos pide un número por teclado y nos dice si es positivo, 
negativo o nulo . Realiza dos versiones: una utilizando IF y otra con el operador ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer02_Positivo_Negativo_Nulo {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num;
        System.out.println("Introduzca un número");
        num = teclado.nextInt();
        if (num > 0) {
            System.out.println("El numero es positivo");
        } else {
            if (num < 0) {
                System.out.println("El número es negativo");
            } else {
                System.out.println("El numero es 0 o nulo");
            }
        }
    }
}