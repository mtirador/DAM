/*Detectar si un número tiene o no parte fraccionaria, visualiza la parte fraccionaria. .
Realiza dos versiones: una utilizando IF y otra con el operador ternario.*/
package tarea_if;

import java.util.Scanner;

public class Ejer04_ParteFraccionaria {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double num;
        double aux;
        
        System.out.println("Introduzca un número distinto de 0");
        num = teclado.nextDouble();
        
        aux = num - (int) num;
        /*al hacer esto lo que estamos haciendo 
        es restar del numero que se da de valor incial su numero en entero, 
        de esta forma almacenamos laparte fraccionaria(sola).*/
        
        if ((aux > 0)) {
            System.out.println("El número tiene parte fraccionaria, que es " + aux);
        } else {
            System.out.println("El número no tiene parte fraccionaria");
        }
    }
}
