/*Escribir un programa que nos pide por teclado un número entero y nos dice si es a la vez 
divisible por 2 y por 5. Realiza dos versiones: una utilizando IF y otra con el operador 
ternario.*/
package tarea_if;

import java.util.Scanner;

public class Ejer03_NumDivisible {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num;
        System.out.println("Introduzca el número distinto de 0");
        num=teclado.nextInt();
        if((num%2 == 0) && (num%5 == 0) && (num!=0)){
            System.out.println("El número es divisible por 2 y 5");
        }else {
            System.out.println("El número no es divisible por 2 y 5");
        }
    }
    
}
