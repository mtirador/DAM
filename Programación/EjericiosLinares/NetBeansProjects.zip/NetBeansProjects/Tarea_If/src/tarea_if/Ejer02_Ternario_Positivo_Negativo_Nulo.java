/*Escribir un programa que nos pide un número por teclado y nos dice si es positivo, 
negativo o nulo . Realiza dos versiones: una utilizando IF y otra con el operador ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer02_Ternario_Positivo_Negativo_Nulo {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num;
        String mensaje;
        System.out.println("Introduzca un número");
        num= teclado.nextInt();
        mensaje = (num > 0)
                ? "El número es positivo"
                : (num < 0)
                ? "El número es ngativo"
                : "El número es nulo";
        System.out.println(mensaje);
    }
}
