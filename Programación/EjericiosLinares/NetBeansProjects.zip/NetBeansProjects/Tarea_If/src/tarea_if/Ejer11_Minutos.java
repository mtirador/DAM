/*Programa que permite determinar la cantidad total a pagar por una llamada telefónica 
tecleando los minutos y teniendo en cuenta que: Toda llamada que dure 1 minuto o 
menos tiene un coste de 0.25€ Cada minuto adicional cuesta cada uno 0.1€*/
package tarea_if;

import java.util.Scanner;

public class Ejer11_Minutos {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        float min;
        float precio;
        
        System.out.println("Introduce el número de minutos de la llamada");
        min = teclado.nextFloat();
        
        if(min <= 1) {
            precio = 0.25F;
        } else {
            precio = (float)(0.25+(Math.ceil((double)min -1)*0.1));
        }
        System.out.println("El precio a pagar es: " + precio + "€");
    }
}
