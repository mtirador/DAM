/*Programa que nos pide un número por teclado y nos dice si está o no comprendido entre 
100 y 1000. Realiza dos versiones: una utilizando IF y otra con el operador ternario.*/
package tarea_if;

import java.util.Scanner;

public class Ejer01_Tarea_100_1000_if {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int numero;
        System.out.println("Introduce un número entre el 100 y el 1000");
        numero = teclado.nextInt();

        if (numero >= 100 && numero <= 1000) {
            System.out.println("El número está comprendido entre 100 y 1000");
        } else {
            System.out.println("El número no está comprendido entre 100 y 1000");
        }
    }

}
