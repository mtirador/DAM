/*Detectar si un número tiene o no parte fraccionaria, visualiza la parte fraccionaria. .
Realiza dos versiones: una utilizando IF y otra con el operador ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer04_ParteFraccionaria_Ternario {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double num;
        double aux;
        String fracc;
        System.out.println("Introduce un numero");
        num= teclado.nextDouble();
        
        aux = num - (int) num;
        
        fracc = (num == (int) num)?
                "El número no tiene parte fraccionaria"
                : "El número tiene parte fraccionaria";
        System.out.println(fracc);
    }
    
}
