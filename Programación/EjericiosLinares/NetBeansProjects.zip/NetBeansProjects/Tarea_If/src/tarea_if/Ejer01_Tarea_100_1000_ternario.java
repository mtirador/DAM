/*Programa que nos pide un número por teclado y nos dice si está o no comprendido entre 
100 y 1000. Realiza dos versiones: una utilizando IF y otra con el operador ternario.*/
package tarea_if;

import java.util.Scanner;

public class Ejer01_Tarea_100_1000_ternario {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int numero;
        System.out.print("Introduce un número: ");
        numero = scanner.nextInt();
        
        String mensaje;        
        mensaje = (numero >= 100 && numero <= 1000) ? "El número está comprendido entre 100 y 1000." : "El número no está comprendido entre 100 y 1000.";
        System.out.println(mensaje);
        
    }  
}
