/*Escribir un programa que nos pide por teclado un número entero y nos dice si es a la vez 
divisible por 2 y por 5. Realiza dos versiones: una utilizando IF y otra con el operador 
ternario.*/
package tarea_if;

import java.util.Scanner;

public class Ejer03_NumDivisible_Ternario {
    public static void main(String[] args) {
        Scanner teclado= new Scanner(System.in);
        int num;
        String mensaje;
        System.out.println("Introduce un número distinto de 0");
        num=teclado.nextInt();
        mensaje = ((num%2 == 0) && (num%5 == 0) && (num != 0))?
                "El número es divisible por 2 y 5"
                : "El número no es divisible por 2 y 5";
        System.out.println(mensaje);
    }
}
