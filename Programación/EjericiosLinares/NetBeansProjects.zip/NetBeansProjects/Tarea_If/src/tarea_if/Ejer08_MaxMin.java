/*Leer tres números y visualizar el máximo y el mínimo. Escribirlos en orden.*/
package tarea_if;

import java.util.Scanner;

public class Ejer08_MaxMin {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num1;
        int num2;
        int num3;
        int max = 0;
        int min = 0;
        int med = 0;
        String mensaje;
        System.out.println("Introduce un número");
        num1 = teclado.nextInt();
        System.out.println("Introduce otro número");
        num2 = teclado.nextInt();
        System.out.println("Introduce el último número");
        num3 = teclado.nextInt();
        med = num3;
        if (num1 > num2) {
            max = num1;
            min = num2;
        } else {
            max = num2;
            min = num1;
        } if (num3 > max) {
            med = max;
            max = num3;
        } else if (num3 < min) {
                med = min;
                min = num3;
                }
        System.out.println(min + "---" + med + "---" + max);

    }
}
