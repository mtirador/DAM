/*Leer un número entre uno y diez y visualizar si es par o impar. 
Realiza dos versiones: una utilizando IF y otra con el operador ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer07_1_10_Par_Impar {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int num;
        System.out.println("Introduce un número del 1 al 10");
        num = teclado.nextInt();

        if (num >= 1 && num <= 10) {
            if (num % 2 == 0) {
                System.out.println("El número es par");
            } else {
                System.out.println("El número es impar");
            }
        } else {
            System.out.println("El número que has introducido no es del 1 al 10");
        }
    }
}
