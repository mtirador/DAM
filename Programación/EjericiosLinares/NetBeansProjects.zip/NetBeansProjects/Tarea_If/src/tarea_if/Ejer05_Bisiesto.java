/*Determinar si un año es o no bisiesto (Un año es bisiesto si es divisible entre 4, excepto 
si es divisible entre 100 pero no entre 400.)*/
package tarea_if;

import java.util.Scanner;

public class Ejer05_Bisiesto {
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int año; 
       
        System.out.println("Introduce un año");
        año = teclado.nextInt();
       
       if (año % 4 ==0) {
           System.out.println("El año es bisiesto");
       } else {
           System.out.println("El año no es bisiesto");
       }
    }
}
