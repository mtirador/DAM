/*Realizar un programa que averigüe si dados dos números 
introducidos por teclado es divisor el uno del otro. 
Realiza dos versiones: una utilizando IF y otra con el operador 
ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer09_Divisor {
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
        int num1;
        int num2;
        System.out.println("Introduce el número 1");
        num1 = teclado.nextInt();
        System.out.println("Introduce el numero 2");
        num2 = teclado.nextInt();
        if(num1 % num2 == 0){
            System.out.println("El número " + num1 + " es divisible de " + num2);
        } else if (num2 % num1 ==0){
            System.out.println("El número " + num2 + " es divisible de " + num1);
        }else {
            System.out.println("Los números no son divisibles entre ellos");
        }
    
  }
}
