/*Dado un número por teclado decir si es par o impar. 
Realiza dos versiones: una utilizando IF y otra con el operador ternario*/
package tarea_if;

import java.util.Scanner;

public class Ejer06_Par_Impar {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num;

        System.out.println("Introduce un número");
        num = teclado.nextInt();
        if (num % 2 == 0) {
            System.out.println("Es par");
        } else {
            System.out.println("Es impar");
        }

    }

}
