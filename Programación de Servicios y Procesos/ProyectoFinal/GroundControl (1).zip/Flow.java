package TareaFinal3;
public class Flow {

	public static void main(String[] args) {
		
		FrontData Front = new FrontData();
		Controler Controler = new Controler();
//		Nave Nave = new NaveMilitar(3565,"A Victory I",300, false,2343);
		//Nave Nave = new NaveMilitar(4456,"Republic Judiciary CR90 Corvette",400, true, 4556);
		//Nave Nave = new NaveTransporte(2233,"Ortho 2",345, false,9908);
		Nave Nave = new NaveTransporte(1112,"Transport Shuttle",690, true,1098);
		
		Controler.SetFrontData(Front);
		Controler.setNave(Nave);
		
		Front.setControler(Controler);
		Nave.setControler(Controler);
	}

}
