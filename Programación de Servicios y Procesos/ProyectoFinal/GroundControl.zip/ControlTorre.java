package TareaFinal3;

public interface ControlTorre {
	String solicitarAterrizar();
    String solicitarDespegar();
    
 
}
